enum Position
{
	PROGRAMMER,
	ARCHITECT,
	MANAGER,
	HR,
	NONE
};